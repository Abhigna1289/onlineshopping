<html>
<body>

<?php
//$conn=mysqli_connect("localhost","root","","shop");

$title=$_POST['title'];
$fn =$_POST['first_name'];
$ln=$_POST['last_name'];
$gen=$_POST['gender'];
$id=$_POST['email'];
$pw=$_POST['password'];
$phone=$_POST['phone_no'];
$add=$_POST['address'];
$city=$_POST['city'];
$coun=$_POST['country'];
$dob=$_POST['dob'];	

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "online_shopping";
	
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO register VALUES ('$title', '$fn', '$ln', '$gen', '$id', '$pw', '$phone', '$add', '$city', '$coun', '$dob')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>
</body>
</html>








